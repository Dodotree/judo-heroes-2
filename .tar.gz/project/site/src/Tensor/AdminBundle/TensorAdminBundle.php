<?php
namespace Tensor\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TensorAdminBundle extends Bundle
{
}
