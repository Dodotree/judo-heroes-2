<?php
namespace Tensor\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TensorUserBundle extends Bundle
{
}
