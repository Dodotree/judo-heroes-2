<?php
namespace Tensor\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TensorCoreBundle extends Bundle
{
}
